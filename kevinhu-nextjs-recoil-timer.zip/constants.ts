export const delayTimeBySecond = 1000
export const delayTimeByMsPercentage = 10
export const defaultStopwatchTimer = 0
export const defaultTimer = 300
export const defaultTimerHH = '00'
export const defaultTimerMM = '05'
export const defaultTimerSS = '00'
